/* Thndr font & color scheme for Tailwind (React/Vite repls).
   1) Put thndr-theme.css's @import + @font-face at the top of your CSS.
   2) Merge this `theme.extend` into your tailwind.config.js.
   Then use classes like: bg-thndr-yellow, text-ink, font-display, shadow-sticker */
module.exports = {
  theme: {
    extend: {
      fontFamily: {
        display: ["Recoleta", "Fraunces", "Georgia", "serif"], // headings
        sans:    ["DM Sans", "system-ui", "sans-serif"],        // body + UI
      },
      colors: {
        thndr: { yellow: "#FFFF00", ink: "#1A1A1A", paper: "#FFFEF2", white: "#FFFFFF" },
        ink:    "#1A1A1A",
        paper:  "#FFFEF2",
        brand: {
          orange:    "#FF7840",
          pink:      "#FF7AAB",
          red:       "#F23054",
          purple:    "#49387B",
          blue:      "#4683F3",
          turquoise: "#38BF9C",
          mint:      "#88FF88",
          darkgreen: "#00321B",
        },
        up:   "#16B477",
        down: "#F23054",
      },
      borderRadius: { sm: "12px", md: "16px", lg: "22px", pill: "999px" },
      boxShadow: { sticker: "4px 4px 0 #1A1A1A" },
      backgroundImage: {
        "grad-sunrise": "linear-gradient(120deg,#FFFF00 0%,#FF7840 100%)",
        "grad-sand":    "linear-gradient(120deg,#FFFF99 0%,#FF7840 60%,#F23054 100%)",
      },
    },
  },
};
